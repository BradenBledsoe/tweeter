import { AuthToken, User } from "tweeter-shared";
import { UserService } from "../model.service/UserService";
import { NavigateFunction } from "react-router-dom";
import { Presenter, View } from "./Presenter";

export interface UserNavigationHookView extends View {
    setDisplayedUser: (user: User) => void;
    navigate: NavigateFunction;
}

export class UserNavigationHookPresenter extends Presenter<UserNavigationHookView> {
    private service = new UserService();

    private extractAlias = (value: string): string => {
        const index = value.indexOf("@");
        return value.substring(index);
    };

    public async navigateToUser(
        event: React.MouseEvent,
        featurePath: string,
        authToken: AuthToken,
        displayedUser: User
    ): Promise<void> {
        event.preventDefault();

        await this.doFailureReportingOperation(async () => {
            const alias = this.extractAlias(event.target.toString());

            const toUser = await this.service.getUser({
                token: authToken.token,
                userAlias: alias,
            });

            if (toUser) {
                if (!toUser.equals(displayedUser)) {
                    this.view.setDisplayedUser(toUser);
                    this.view.navigate(`${featurePath}/${toUser.alias}`);
                }
            }
        }, "get user");
    }
}
